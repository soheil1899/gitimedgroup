@extends('admin.dashboard')

@section('page')
    <about>

    </about>

@endsection
