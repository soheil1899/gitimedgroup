<div>
    <div>سفارش شما از طرف {{ $messege->name }}</div>
    <div>E-mail: {{ $messege->email }}</div>
    <div>شماره تماس:  {{ $messege->phone }}</div>
    <div>{{ $messege->messege }}</div>
</div>