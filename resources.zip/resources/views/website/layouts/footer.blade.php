<footer>

<div class="footer-top">

    <a href="{{$setting['instagram']}}">
        <i class="fab fa-instagram fa-2x mr-2"></i>
    </a>
    <a href="{{$setting['telegram']}}">
        <i class="fab fa-telegram fa-2x mr-2"></i>
    </a>
    <a href="{{$setting['googleplus']}}">
        <i class="fab fa-google-plus fa-2x mr-2"></i>
    </a>
    <a href="{{$setting['twitter']}}">
        <i class="fab fa-twitter fa-2x mr-2"></i>
    </a>
</div>


    <div class="bottem container">
        <p>
        کلیه حقوق مادی و معنوی این وبسایت متعلق به
            {{$setting['websitename']}}
            می باشد.
        </p>
        <p>
            طراحی با گروه افرنگ - تیس نسخه 4.0
        </p>
    </div>



</footer>
