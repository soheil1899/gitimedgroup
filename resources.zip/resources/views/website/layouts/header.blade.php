<header>
{{--    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"--}}
{{--         xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="100%"--}}
{{--         viewBox="0 0 1943.2 502" class="tiss-top-svg" xml:space="preserve">--}}




{{--    <defs>--}}
{{--    </defs>--}}
{{--        <path class="st0" d="M2.2,502c0,0,1180.6-558.7,1941,0V106.6H2.2V502z">--}}

{{--        </path>--}}
{{--        <path class="st1" d="M0,467.1c0,0,1138.1-451.9,1943.2-147.2V0H0V467.1z"></path>--}}
{{--    </svg>--}}

{{--    <div class="header-top">--}}

{{--    </div>--}}
{{--    <div class="header-bottom">--}}


{{--    </div>--}}


    <div class="header-top">
        <img src="/media/user/12.jpg" alt="" class="header-img">

    </div>
    <div class="header-bottom py-1">

    </div>




    <div class="row">
    <div class="header-title col-12 d-none d-sm-block">
        <h2 class="mr-5 mt-3 badcolor">
            <strong>
{{$setting['websitename']}}
{{--                شرکت گیتی فناوری و پزشکی هوشمند (شماره ثبت:8102)--}}
            </strong>
        </h2>
    </div>
    <div class="header-title col-12 d-block d-sm-none">
        <h4 class="badcolor mt-3">
            <strong>
{{$setting['websitename']}}
            </strong>
        </h4>
    </div>

{{--    <div class="header-title-en col-6 d-none d-lg-block">--}}
{{--        <h2>--}}
{{--            <strong>--}}
{{--                Semnan Branch of Iranian Neuroscience Society--}}
{{--            </strong>--}}
{{--        </h2>--}}
{{--    </div>--}}

    </div>


</header>
