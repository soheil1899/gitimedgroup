module.exports = {
    regsiter : 'ثبت نام ',
    forgetpass : 'فراموشی رمز عبور ',
    Language : 'Language',
    wellcome : 'خوش آمدید',
    Profilecheck : 'چک کردن پروفایل',
    Profile : ' پروفایل',
    Quit : 'خروج',
    WrongCode : 'کد اشتباه می باشد',
}