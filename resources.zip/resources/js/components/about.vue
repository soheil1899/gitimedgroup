<template>
    <div>
        <div class="container">
            <div class="card coprightrightbox">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <div class="aboutorangbox">
                                <div>
                                    <!-- Generator: Adobe Illustrator 22.1.0, SVG Export Plug-In  -->
                                    <svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="59.3px" height="56.1px" viewBox="0 0 59.3 56.1" style="enable-background:new 0 0 59.3 56.1;"
	 xml:space="preserve">

<defs>
</defs>
<path class="st3" d="M59.3,35c-0.7,2.2-1.6,4.2-2.7,6.1c-1.7,0.6-3.5,1-5.3,1.3c1.4-1.7,2.6-3.6,3.5-5.7
	C56.3,36.3,57.9,35.7,59.3,35z"/>
<path class="st3" d="M56.6,41.2c-5.3,9-15,15-26.2,15C13.6,56.1,0,42.5,0,25.8c0-6.1,1.8-11.7,4.8-16.5c0.3,1.8,0.7,3.6,1.2,5.3
	C4.4,18,3.6,21.8,3.6,25.8c0,14.8,12,26.8,26.8,26.8c8.5,0,16-3.9,20.9-10.1C53.1,42.2,54.9,41.7,56.6,41.2z"/>
<path class="st3" d="M9.1,4.1c0,1.6,0.2,3.3,0.4,4.8c-1.4,1.7-2.6,3.6-3.5,5.7c-0.5-1.7-0.9-3.5-1.2-5.3C6.1,7.4,7.5,5.7,9.1,4.1z"
	/>
<path class="st3" d="M51.8,25.8c0,1-0.1,2-0.2,2.9c-1-1.6-2.1-3-3.4-4.3c-0.7-9.2-8.4-16.5-17.8-16.5c-9.9,0-17.9,8-17.9,17.9
	c0,2,0.3,3.9,0.9,5.7c-0.7,1.7-1.2,3.5-1.4,5.3c-1.9-3.2-3.1-7-3.1-11c0-11.8,9.6-21.4,21.4-21.4C42.2,4.3,51.8,13.9,51.8,25.8z"/>
<path class="st3" d="M48.9,40.9c0.9,0,1.8,0,2.6-0.1c-4.7,6.6-12.4,10.9-21.1,10.9c-14.3,0-25.9-11.6-25.9-25.9
	C4.5,12.4,14.7,1.3,27.7,0c-0.9,1.3-1.7,2.6-2.3,4C15.5,6.3,8,15.2,8,25.8c0,12.3,10,22.3,22.3,22.3c6.5,0,12.4-2.8,16.5-7.3
	C47.5,40.9,48.2,40.9,48.9,40.9z"/>
</svg>
                                    <div class="aboutafrang">AfrangArt</div>


                                </div>
                            </div>
                        </div>
                        <div  class="productname col-8">
                            <div class="row">
                                <div class="col-9 text-left">
                                    <h1 class="tissengineabout"> TISS ENGINE</h1>
                                </div>
                                <div class="col-3">
                                    <div>
                                        <!-- Generator: Adobe Illustrator 22.1.0, SVG Export Plug-In  -->
                                        <svg   version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="73px" height="73px" viewBox="0 0 73 73" style="enable-background:new 0 0 73 73;" xml:space="preserve">

<defs>
</defs>
<path class="st0" d="M36.5,0C56.7,0,73,16.3,73,36.5C73,56.7,56.7,73,36.5,73C16.3,73,0,56.7,0,36.5C0,16.3,16.3,0,36.5,0z
	 M68.7,36.5c0-17.8-14.4-32.2-32.2-32.2S4.3,18.7,4.3,36.5s14.4,32.2,32.2,32.2S68.7,54.3,68.7,36.5z"/>
<path class="st0" d="M36.5,5.4c17.2,0,31.1,13.9,31.1,31.1S53.7,67.6,36.5,67.6S5.4,53.7,5.4,36.5S19.3,5.4,36.5,5.4z M36.5,63.3
	c14.8,0,26.8-12,26.8-26.8c0-14.8-12-26.8-26.8-26.8c-14.8,0-26.8,12-26.8,26.8C9.7,51.3,21.7,63.3,36.5,63.3z"/>
<g>
	<path class="st1" d="M37.3,50.1H15.4v-9.9l21.9-26h10.5v26.5h11l-4.4,9.3h-6.5v8.1H37.3V50.1z M37.3,40.8V27.2L25.7,40.8H37.3z"/>
</g>
<path class="st0" d="M62.3,36.5c0,14.2-11.5,25.8-25.8,25.8c-14.2,0-25.8-11.5-25.8-25.8c0-14.2,11.5-25.8,25.8-25.8
	C50.7,10.7,62.3,22.3,62.3,36.5z M58,36.5C58,24.6,48.4,15,36.5,15C24.6,15,15,24.6,15,36.5C15,48.4,24.6,58,36.5,58
	C48.4,58,58,48.4,58,36.5z"/>
</svg>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <hr>
                    <div class="copyrighttext">
                        <p><strong>4.0</strong></p>
                        <p>© 2008-2019 AfrangArt. All right reserved.</p>
                        <p>AfrangrArt, the AfrangArt and  Tiss Engine either registered tradmarks or tarnarjes of Afrang Gostar Advertising Center in Iran.
                        <p> </p>
                        <p> </p>

                        <p>Created With Laravel , VueJs, PHP, postgreSQL</p>
                        <p>Lead Programming Group: Esmail Poryosef</p>
                        <p>Email: info@afrangart.com afrangart@gmail.com</p>
                        <p>Website: www.tisscms.ir   www.afrangart.com www.afrangart.ir</p>
                        <p>Support Call: +98(912)7689580</p>

                    </div>
                    <div class="copyrighttext copyrighttextfa">
                        <p><strong>4.0</strong></p>
                        <p> افرنگ آرت © 2008-2019. تمامی حقوق محفوظ است</p>
                        <p>افرنگ آرت، سیستم تیس با مارک تجاری در کانون تبلیغاتی افرنگ گستر ثبت گردیده است
                        <p> </p>
                        <p> </p>

                        <p>ساخته شده با لاراول، ,وی یو جی اس ،  پی اچ پی، پوست گری اس کیو ال</p>
                        <p>سرپرست گروه برنامه نویسی: اسماعیل پوریوسف</p>
                        <p>info@afrangart.com afrangart@gmail.com</p>
                        <p> www.tisscms.ir   www.afrangart.com www.afrangart.ir</p>
                        <p>شماره پشتیبانی: 09127689580</p>

                    </div>
                    <hr>
                    <img class="logoscopright" src="/asset/png/logos.png">
                </div>
            </div>
        </div>

    </div>
</template>

<script>
    export default {
        name: "about"
    }
</script>

<style scoped>
    .st0{fill:#686464;}
    .st1{fill:#F37021;}
    .tissengineabout{ font-size: 45px; padding-top: 20px;}
    .st3{fill:#FFFFFF;}
    .aboutorangbox{background-color: #F1645F; width: 80px; padding: 5px;
        padding-top: 45px;
        text-align: center;

    }
    .productname{ padding-top: 45px;}
    .aboutafrang{ color:#fff;}
    .logoscopright{ height: 50px;}
    .coprightrightbox{ margin-top: 10%;}
    .copyrighttextfa{ font-family: IRANSans !important; text-align: right !important; direction: rtl;}
    .copyrighttext{ font-size: 12px; direction: ltr; font-family: arial; text-align:left; line-height:4px; color:gray;}
</style>